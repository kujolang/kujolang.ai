# Async tasks

Wait for an async function to return a value.

```kujo
// Simple async test

async func get_value() {
    return 42;
}

let p = get_value();
println("Promise type: ", type(p));
let result = await p;
println("Result: ", result);

```

**Expected output:**

```text
Promise type:  promise
Result:  42

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Wait for an async function to return a value.

Kujo: Programming language for AI-native software
