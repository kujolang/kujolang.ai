# HTTP and networking

Read a local HTTP server example.

```kujo
# Simple HTTP Server Example - Hello World
# Demonstrates basic HTTP server usage with a single route

print("http_server_simple: long-running server example skipped in VM auto-run mode")
exit(0)

# Create HTTP server on port 8080
server := http_server(8080)

# Add a simple GET route
server := server.route("GET", "/", func(req) {
    return http_response(200, "Hello, World!")
})

# Add another route
server := server.route("GET", "/hello", func(req) {
    return http_response(200, "Hello from Kujo!")
})

# Start the server (blocking - will run until Ctrl+C)
server.listen()

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: check. We checked the source only. The server code needs a free local port; the upstream sample skips server startup in automatic VM runs.

---

Read a local HTTP server example.

Kujo: Programming language for AI-native software
