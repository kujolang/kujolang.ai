# Enums and pattern matching

Handle tagged values and Result variants.

```kujo
# Pattern matching examples using current Kujo match syntax.

enum Status {
    Success,
    Failure
}

func status_for(code) {
    if code == 200 {
        return Status::Success("ok")
    }
    return Status::Failure("not ok")
}

let result := status_for(200)

match result {
    case Status::Success(message): {
        print("success: " + message)
    }
    case Status::Failure(error): {
        print("failure: " + error)
    }
}

let maybe_value := Ok(42)

match maybe_value {
    case Ok(value): {
        print("value: " + to_string(value))
    }
    case Err(message): {
        print("error: " + message)
    }
}

```

**Expected output:**

```text
value: 42

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Handle tagged values and Result variants.

Kujo: Programming language for AI-native software
