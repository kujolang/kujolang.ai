# Hello World

Print your first message.

```kujo
# Expected output:
# Kujo Kujo!

print("Kujo Kujo!")

```

**Expected output:**

```text
Kujo Kujo!

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Print your first message.

Kujo: Programming language for AI-native software
