# Structured output validation

Check local data against a schema without calling a model.

```kujo
func kv(label, value) {
    print(label + ": " + to_string(value))
}

let schema := {
    "type": "object",
    "required": ["name", "scores"],
    "properties": {
        "name": {
            "type": "string",
            "minLength": 2
        },
        "scores": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "number",
                "minimum": 0,
                "maximum": 100
            }
        }
    },
    "additionalProperties": false
}

let valid_report := json_schema_validate({
    "name": "Kujo",
    "scores": [95, 88]
}, schema)

let invalid_report := json_schema_validate({
    "name": "K",
    "scores": [101],
    "debug": true
}, schema)

kv("valid", valid_report["valid"])
kv("invalid", invalid_report["valid"])
kv("errors", invalid_report["errors"])

```

**Expected output:**

```text
valid: true
invalid: false
errors: [{"keyword": minLength, "message": string length is less than 2, "path": /name}, {"keyword": maximum, "message": number is greater than 100, "path": /scores/0}, {"keyword": additionalProperties, "message": additional property 'debug' is not allowed, "path": /debug}]

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Check local data against a schema without calling a model.

Kujo: Programming language for AI-native software
