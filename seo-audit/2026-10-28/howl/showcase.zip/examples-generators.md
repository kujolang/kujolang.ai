# Generators

Generate values as you need them.

```kujo
# Test: Generator Functions
# Tests generator creation, yielding, and iteration
# Both runtimes resume loops lazily and preserve state across every yield.

print("=== Test 1: Simple Generator ===")
func* count() {
    yield 1
    yield 2
    yield 3
}

gen := count()
print("Generator created, type:")
print(type(gen))

print("")
print("=== Test 2: Generator Iteration ===")
for n in count() {
    print("Value:")
    print(n)
}

print("")
print("=== Test 3: Generator with State ===")

```

**Expected output:**

```text
=== Test 1: Simple Generator ===
Generator created, type:
generator

=== Test 2: Generator Iteration ===
Value:
1
Value:
2
Value:
3

=== Test 3: Generator with State ===

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Generate values as you need them.

Kujo: Programming language for AI-native software
