# Modules and imports

Read examples of dotted and named imports.

```kujo
# Parse-only module import tour.
# To run this pattern, create the imported files beside your script or inside a package root.

import math_helpers
from metrics import average, total
from src.util import value
from src.core.math import add

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: check. The imported modules are not included, so this example cannot run on its own. We check the source only.

---

Read examples of dotted and named imports.

Kujo: Programming language for AI-native software
