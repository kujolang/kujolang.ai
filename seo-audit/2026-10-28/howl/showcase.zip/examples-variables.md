# Variables and types

Create variables with let and print their values.

```kujo
# Expected output:
# tool: kujo
# status: ready

let tool := "kujo"
let status := "ready"

print("tool: " + tool)
print("status: " + status)

```

**Expected output:**

```text
tool: kujo
status: ready

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Create variables with let and print their values.

Kujo: Programming language for AI-native software
