# AI streaming

Read a recorded response through a streaming callback.

```kujo
func kv(label, value) {
    print(label + ": " + to_string(value))
}

func on_chunk(delta, raw_chunk) {
    kv("delta", delta)
    kv("raw", raw_chunk)
    return true
}

let replay_options := {
    "endpoint": "http://127.0.0.1:1/v1/chat/completions",
    "model": "gpt-replay",
    "provider": "mock-provider",
    "cassette": {
        "mode": "replay",
        "dir": "tests/fixtures/ai_cassettes"
    }
}

let result := ai_stream_chat("Stream please", replay_options, on_chunk)
kv("stream_result", result)

```

**Expected output:**

```text
delta: chunk one
raw: {"choices": [{"delta": {"content": chunk one}}]}
delta: chunk two
raw: {"choices": [{"delta": {"content": chunk two}, "finish_reason": stop}], "usage": {"completion_tokens": 3, "prompt_tokens": 3, "total_tokens": 6}}
stream_result: Ok({"chunks": [chunk one, chunk two], "finish_reason": stop, "headers": {"content-type": application/json}, "json": {"choices": [{"delta": {"content": chunk one}}, {"delta": {"content": chunk two}, "finish_reason": stop}], "usage": {"completion_tokens": 3, "prompt_tokens": 3, "total_tokens": 6}}, "model": gpt-replay, "provider": mock-provider, "status": 200, "text": {"choices":[{"delta":{"content":"chunk one"}},{"delta":{"content":"chunk two"},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":3,"total_tokens":6}}, "usage": {"completion_tokens": 3, "prompt_tokens": 3, "total_tokens": 6}})

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. Use the bundled fixtures for offline replay. Live calls require provider credentials and network access and may cost money.

---

Read a recorded response through a streaming callback.

Kujo: Programming language for AI-native software
