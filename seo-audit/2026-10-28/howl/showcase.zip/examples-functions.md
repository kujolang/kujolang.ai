# Functions and operators

Add the numbers in an array with a function.

```kujo
# Expected output:
# total: 42

func total(values) {
    mut sum := 0
    for value in values {
        sum = sum + value
    }
    return sum
}

let scores := [8, 13, 21]
print("total: " + to_string(total(scores)))

```

**Expected output:**

```text
total: 42

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Add the numbers in an array with a function.

Kujo: Programming language for AI-native software
