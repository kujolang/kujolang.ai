# Error handling

Catch an error and keep the program running.

```kujo
# Test better error messages with try/except
func process(x) {
    if x == 0 {
        throw("Cannot process zero value")
    }
    return x * 2
}

try {
    result := process(0)
    print("Result:", result)
} except err {
    print("Error caught:", err)
}

print("Program continues after error handling")

```

**Expected output:**

```text
Error caught: Error { line: 0, message: Cannot process zero value, stack: [process] }
Program continues after error handling

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Catch an error and keep the program running.

Kujo: Programming language for AI-native software
