# Channels

Send a value through a first-in, first-out channel.

```kujo
# Channels - Thread Communication Example
# Demonstrates using channels to communicate between threads

print("=== Channels for Thread Communication Demo ===")
print("")

# Example 1: Basic channel send/receive
print("1. Basic channel usage")
chan := channel()

print("Sending value 42 to channel...")
chan.send(42)

print("Receiving from channel...")
value := chan.receive()
print("Received:")
print(value)
print("")

```

**Expected output:**

```text
=== Channels for Thread Communication Demo ===

1. Basic channel usage
Sending value 42 to channel...
Receiving from channel...
Received:
42


```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. This example uses one scope. It does not share captured state across spawned tasks.

---

Send a value through a first-in, first-out channel.

Kujo: Programming language for AI-native software
