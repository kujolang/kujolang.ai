# Control flow

Choose which code runs with a comparison.

```kujo
# Expected output:
# pass: build score

let score := 42

if score >= 40 {
    print("pass: build score")
} else {
    print("retry: build score")
}

```

**Expected output:**

```text
pass: build score

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Choose which code runs with a comparison.

Kujo: Programming language for AI-native software
