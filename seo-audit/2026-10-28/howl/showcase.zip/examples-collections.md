# Collections

Build a report from arrays and dictionaries.

```kujo
# Expected output:
# build total: 42

let scores := [8, 13, 21]
let report := {"name": "build", "total": scores[0] + scores[1] + scores[2]}

print(report["name"] + " total: " + to_string(report["total"]))

```

**Expected output:**

```text
build total: 42

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Build a report from arrays and dictionaries.

Kujo: Programming language for AI-native software
