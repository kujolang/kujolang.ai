# An inspectable development workflow

Define scope, test changes and inspect the evidence.

```yaml
objective: "Implement and verify the customer endpoint within the agreed scope"
max_iterations: 2
max_no_progress: 1
max_consecutive_failures: 2
eval_gates:
  - id: project_tests
    command: "npm test"
    required: true
  - id: diff_check
    command: "git diff --check"
    required: true
commit:
  enabled: false
  push: false

```

Configuration example; replace npm test with the existing project test command.

---

Define scope, test changes and inspect the evidence.

Kujo: Programming language for AI-native software
