# Learn Kujo

Install the runtime and run your first program.

```kujo
# Expected output:
# Kujo Kujo!

print("Kujo Kujo!")

```

**Expected output:**

```text
Kujo Kujo!

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Install the runtime and run your first program.

Kujo: Programming language for AI-native software
