# Kujo language examples

Code, commands, expected output and pinned sources.

```kujo
# Expected output:
# Kujo Kujo!

print("Kujo Kujo!")

```

**Expected output:**

```text
Kujo Kujo!

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Code, commands, expected output and pinned sources.

Kujo: Programming language for AI-native software
