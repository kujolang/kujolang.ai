# Inspect AI responses

Replay a model response and inspect a structured error offline.

```kujo
func kv(label, value) {
    print(label + ": " + value)
}

let replay_options := {
    "endpoint": "http://127.0.0.1:1/v1/chat/completions",
    "model": "gpt-replay",
    "provider": "mock-provider",
    "cassette": {
        "mode": "replay",
        "dir": "tests/fixtures/ai_cassettes"
    }
}

let ok_result := ai_chat("Hello model", replay_options)
kv("ok_result", to_string(ok_result))

let structured_error_options := {
    "endpoint": "http://127.0.0.1:1/v1/chat/completions",
    "model": "gpt-replay",
    "structured_errors": true,
    "cassette": {
        "mode": "replay",
        "dir": "tests/fixtures/ai_cassettes"
    }
}

let error_result := ai_chat("Rate limit", structured_error_options)
kv("structured_error", to_string(error_result))

```

**Expected output:**

```text
ok_result: Ok({"finish_reason": tool_calls, "headers": {"content-type": application/json}, "json": {"choices": [{"finish_reason": tool_calls, "message": {"content": hello from cassette, "tool_calls": [{"function": {"arguments": {"query":"kujo"}, "name": lookup}, "id": call_1}]}}], "usage": {"completion_tokens": 5, "prompt_tokens": 7, "total_tokens": 12}}, "message": hello from cassette, "model": gpt-replay, "provider": mock-provider, "status": 200, "text": {"choices":[{"finish_reason":"tool_calls","message":{"content":"hello from cassette","tool_calls":[{"id":"call_1","function":{"name":"lookup","arguments":"{\"query\":\"kujo\"}"}}]}}],"usage":{"prompt_tokens":7,"completion_tokens":5,"total_tokens":12}}, "tool_calls": [{"arguments_json": {"query":"kujo"}, "id": call_1, "name": lookup}], "usage": {"completion_tokens": 5, "prompt_tokens": 7, "total_tokens": 12}})
structured_error: Err({"body_excerpt": {"error":{"code":"rate_limit_exceeded","message":"slow down"}}, "http_status": 429, "kind": rate_limited, "message": ai_chat failed with HTTP status 429: {"error":{"code":"rate_limit_exceeded","message":"slow down"}}, "provider_code": rate_limit_exceeded, "retry_after_ms": 3000})

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. Use the samples bundle so the recorded response fixtures are available. Replay makes no live model call.

---

Replay a model response and inspect a structured error offline.

Kujo: Programming language for AI-native software
