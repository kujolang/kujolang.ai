# Handle missing values

Look up users and handle both Some and None.

```kujo
func find_user_by_id(id) {
    if id == 1 {
        return Some("Alice")
    }
    if id == 2 {
        return Some("Bob")
    }
    if id == 3 {
        return Some("Charlie")
    }
    return None
}

let users := [1, 2, 99, 3]
for user_id in users {
    let user := find_user_by_id(user_id)
    match user {
        case Some(name): {
            print("User " + to_string(user_id) + ": " + name)
        }
        case None: {
            print("User " + to_string(user_id) + ": Not found")
        }
    }
}

```

**Expected output:**

```text
User 1: Alice
User 2: Bob
User 99: Not found
User 3: Charlie

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Look up users and handle both Some and None.

Kujo: Programming language for AI-native software
