# Nested dictionaries

Store a profile in a dictionary and read its nested fields.

```kujo
# Dictionary examples

# Create a dictionary
let person := {"name": "Alice", "age": 30, "city": "Portland"};
print("Person:", person);

# Access values
print("Name:", person["name"]);
print("Age:", person["age"]);
print("City:", person["city"]);

# Nested dictionaries
let user := {
    "username": "alice123",
    "profile": {"email": "alice@example.com", "verified": 1}
};
print("User:", user);
print("Username:", user["username"]);
print("Profile:", user["profile"]);

```

**Expected output:**

```text
Person: {"age": 30, "city": Portland, "name": Alice}
Name: Alice
Age: 30
City: Portland
User: {"profile": {"email": alice@example.com, "verified": 1}, "username": alice123}
Username: alice123
Profile: {"email": alice@example.com, "verified": 1}

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Store a profile in a dictionary and read its nested fields.

Kujo: Programming language for AI-native software
