# Sort and summarize arrays

Sort, reverse, deduplicate and sum a list of numbers.

```kujo
func print_lines(lines) {
    for line in lines {
        print(line)
    }
}

func section(title) {
    print("")
    print(title)
}

func kv(label, value) {
    print("   " + label + ": " + to_string(value))
}

func show_result(label, value) {
    print("   " + label + " = " + to_string(value))
    print()
}

print_lines([
    "=== Array Utilities Demo ===",
    ""
])

# Sample data
nums := [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]
kv("Original array", nums)

# 1. Sort - arrange in ascending order
section("1. SORT - Arrange in ascending order")
sorted := sort(nums)
show_result("sort(nums)", sorted)

# 2. Reverse - reverse the order
section("2. REVERSE - Reverse the order")
reversed := reverse(nums)
show_result("reverse(nums)", reversed)

# 3. Unique - remove duplicates
```

> Example truncated for display. See the source file for the full example.

**Expected output:**

```text
=== Array Utilities Demo ===

   Original array: [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]

1. SORT - Arrange in ascending order
   sort(nums) = [1, 1, 2, 3, 3, 4, 5, 5, 6, 9]


2. REVERSE - Reverse the order
   reverse(nums) = [3, 5, 6, 2, 9, 5, 1, 4, 1, 3]


3. UNIQUE - Remove duplicates (preserves order)
   unique(nums) = [3, 1, 4, 5, 9, 2, 6]


4. SUM - Calculate total
   sum(nums) = 39


```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Sort, reverse, deduplicate and sum a list of numbers.

Kujo: Programming language for AI-native software
