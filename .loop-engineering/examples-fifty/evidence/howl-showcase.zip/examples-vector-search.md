# Compare vectors

Normalize vectors, compare their similarity and rank matches.

```kujo
func kv(label, value) {
    print(label + ": " + to_string(value))
}

let query := [1.0, 0.0, 0.0]
let documents := [
    [1.0, 0.0, 0.0],
    [0.0, 1.0, 0.0],
    [0.8, 0.2, 0.0]
]

kv("dot", vec_dot(query, documents[2]))
kv("norm", vec_norm([3, 4]))
kv("normalized", vec_normalize([3, 4]))
kv("cosine", vec_cosine(query, documents[2]))
kv("top", vec_top_k(query, documents, 2))

```

**Expected output:**

```text
dot: 0.8
norm: 5
normalized: [0.6, 0.8]
cosine: 0.9701425001453319
top: [{"index": 0, "score": 1}, {"index": 2, "score": 0.9701425001453319}]

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Normalize vectors, compare their similarity and rank matches.

Kujo: Programming language for AI-native software
