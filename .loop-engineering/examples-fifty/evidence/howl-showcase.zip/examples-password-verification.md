# Verify a password

Hash a sample password and check matching and incorrect input.

```kujo
let password := "my_secure_password"
let hashed := hash_password(password)

if verify_password(password, hashed) {
    print("password verified")
}

if !verify_password("wrong_password", hashed) {
    print("wrong password rejected")
}

```

**Expected output:**

```text
password verified
wrong password rejected

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. The credentials in this sample are dummy values.

---

Hash a sample password and check matching and incorrect input.

Kujo: Programming language for AI-native software
