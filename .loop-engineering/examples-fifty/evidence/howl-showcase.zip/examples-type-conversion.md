# Convert text to numbers

Read an age and a balance from strings.

```kujo
age := to_int("25")
balance := to_float("150.75")
print("Age: " + to_string(age))
print("Balance: " + to_string(balance))

if age >= 18 {
    print("Status: Adult")
}

```

**Expected output:**

```text
Age: 25
Balance: 150.75
Status: Adult

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Read an age and a balance from strings.

Kujo: Programming language for AI-native software
