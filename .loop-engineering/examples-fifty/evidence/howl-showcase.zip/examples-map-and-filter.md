# Map and filter arrays

Transform numbers and names, then keep the even numbers.

```kujo
func print_lines(lines) {
    for line in lines {
        print(line)
    }
}

func section(title, description) {
    print_lines([
        title,
        "   " + description,
        ""
    ])
}

func show_pair(title, first_label, first_value, second_label, second_value) {
    print("   " + title + ":")
    print("   " + first_label + ": " + to_string(first_value))
    print("   " + second_label + ": " + to_string(second_value))
    print()
}

func show_value(title, label, value) {
    print("   " + title + ":")
    print("   " + label + ": " + to_string(value))
    print()
}

func show_step(label, value) {
    print("   " + label + ": " + to_string(value))
}

print_lines([
    "=== Array Higher-Order Functions ===",
    ""
])

# ============================================================================
# MAP - Transform each element
# ============================================================================
section("1. MAP - Transform elements", "Applies a function to each element, returning a new array")
```

> Example truncated for display. See the source file for the full example.

**Expected output:**

```text
=== Array Higher-Order Functions ===

1. MAP - Transform elements
   Applies a function to each element, returning a new array

   Square numbers:
   Input: [1, 2, 3, 4, 5]
   Output: [1, 4, 9, 16, 25]

   Celsius to Fahrenheit:
   Celsius: [0, 10, 20, 30, 40]
   Fahrenheit: [32, 50, 68, 86, 104]

   Capitalize names:
   Input: [alice, bob, charlie]
   Output: [ALICE, BOB, CHARLIE]

2. FILTER - Select matching elements
   Returns only elements where the function returns true

```

> Expected output truncated for display.

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Transform numbers and names, then keep the even numbers.

Kujo: Programming language for AI-native software
