# Encode URL components

Encode spaces, punctuation and Unicode for a URL component.

```kujo
# RFC 3986 query-component encoding preserves unreserved characters and
# percent-encodes every other UTF-8 byte.
print(encode_uri_component("café & tea"))
print(encode_uri_component("東京/検索"))

```

**Expected output:**

```text
caf%C3%A9%20%26%20tea
%E6%9D%B1%E4%BA%AC%2F%E6%A4%9C%E7%B4%A2

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Encode spaces, punctuation and Unicode for a URL component.

Kujo: Programming language for AI-native software
