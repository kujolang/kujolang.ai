# Combine arrays

Combine arrays, insert values and copy a list with spread syntax.

```kujo
# Combine arrays
fruits := ["apple", "banana"]
vegetables := ["carrot", "broccoli"]
food := [...fruits, ...vegetables]
print("All food: " + to_string(food))

# Add elements while spreading
numbers := [2, 3, 4]
extended := [1, ...numbers, 5, 6]
print("Extended numbers: " + to_string(extended))

# Clone an array
original := [10, 20, 30]
clone := [...original]
print("Clone: " + to_string(clone))

```

**Expected output:**

```text
All food: [apple, banana, carrot, broccoli]
Extended numbers: [1, 2, 3, 4, 5, 6]
Clone: [10, 20, 30]

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Combine arrays, insert values and copy a list with spread syntax.

Kujo: Programming language for AI-native software
