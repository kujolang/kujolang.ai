# String interpolation

Put values and calculations into a message.

```kujo
# Simple variable interpolation
name := "Alice"
greeting := "Hello, ${name}!"
print(greeting)

# Number interpolation
age := 25
bio := "I am ${age} years old"
print(bio)

print("\n=== Expression Interpolation ===")

# Arithmetic expressions
x := 10
y := 5
result := "The sum of ${x} and ${y} is ${x + y}"
print(result)

# Multiple expressions
width := 5
height := 3
area_msg := "Rectangle: ${width} x ${height} = ${width * height}"
print(area_msg)

```

**Expected output:**

```text
Hello, Alice!
I am 25 years old

=== Expression Interpolation ===
The sum of 10 and 5 is 15
Rectangle: 5 x 3 = 15

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Put values and calculations into a message.

Kujo: Programming language for AI-native software
