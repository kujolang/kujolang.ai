# Read and write YAML

Read a YAML configuration and check its serialized output.

```kujo
# YAML parsing and generation

let yaml_text := "name: Kujo\nkind: language\nfeatures:\n  - local-first\n  - deterministic"
let document := parse_yaml(yaml_text)

assert_equal(document["name"], "Kujo")
assert_equal(len(document["features"]), 2)

let generated := to_yaml(document)
let round_trip := parse_yaml(generated)

assert_equal(round_trip["kind"], "language")
assert_equal(round_trip["features"][0], "local-first")
print("parsed YAML:", document)

```

**Expected output:**

```text
parsed YAML: {"features": [local-first, deterministic], "kind": language, "name": Kujo}

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Read a YAML configuration and check its serialized output.

Kujo: Programming language for AI-native software
