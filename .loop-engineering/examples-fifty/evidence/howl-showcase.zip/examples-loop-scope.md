# Accumulate a total

Update a running total as a loop visits each number.

```kujo
sum := 0
for n in [1, 2, 3, 4, 5] {
    sum := sum + n
    print("Current sum:", sum)
}
print("Final sum:", sum)

```

**Expected output:**

```text
Current sum: 1
Current sum: 3
Current sum: 6
Current sum: 10
Current sum: 15
Final sum: 15

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Update a running total as a loop visits each number.

Kujo: Programming language for AI-native software
