# Compose functions

Pass one function result into the next to calculate a value or format text.

```kujo
func double(x) { return x * 2 }
func add_five(x) { return x + 5 }
func square(x) { return x * x }

let result := square(add_five(double(3)))
print(result)

func exclaim(s) { return s + "!" }
let greeting := exclaim(to_upper("hello"))
print(greeting)

```

**Expected output:**

```text
121
HELLO!

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Pass one function result into the next to calculate a value or format text.

Kujo: Programming language for AI-native software
