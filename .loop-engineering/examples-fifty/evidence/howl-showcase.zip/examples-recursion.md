# Calculate a factorial

Call a function recursively until it reaches a base case.

```kujo
// Test factorial with VM
func factorial(n) {
    if n <= 1 {
        return 1
    }
    return n * factorial(n - 1)
}

result := factorial(5)
print("factorial(5) =", result)

```

**Expected output:**

```text
factorial(5) = 120

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Call a function recursively until it reaches a base case.

Kujo: Programming language for AI-native software
