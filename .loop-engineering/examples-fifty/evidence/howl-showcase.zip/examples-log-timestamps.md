# Extract log timestamps

Find timestamps in sample log lines with a regular expression.

```kujo
// Sample log entries
logs := [
    "[2026-01-23 10:15:30] INFO: Application started successfully",
    "[2026-01-23 10:15:31] DEBUG: Loading configuration from config.json",
    "[2026-01-23 10:15:32] INFO: Connected to database",
    "[2026-01-23 10:16:45] WARNING: High memory usage detected: 85%",
    "[2026-01-23 10:17:12] ERROR: Failed to connect to API endpoint",
    "[2026-01-23 10:17:15] INFO: Retrying connection...",
    "[2026-01-23 10:17:18] ERROR: Connection timeout after 3 attempts",
    "[2026-01-23 10:18:00] INFO: Fallback mode activated"
]

print("Sample Logs:")
for log in logs {
    print("  " + log)
}
print("")

// Extract timestamps
print("1. Extracting Timestamps:")
timestamp_pattern := "\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}"
for log in logs {
    timestamps := regex_find_all(log, timestamp_pattern)
    if len(timestamps) > 0 {
        print("  " + timestamps[0])
    }
}

```

**Expected output:**

```text
Sample Logs:
  [2026-01-23 10:15:30] INFO: Application started successfully
  [2026-01-23 10:15:31] DEBUG: Loading configuration from config.json
  [2026-01-23 10:15:32] INFO: Connected to database
  [2026-01-23 10:16:45] WARNING: High memory usage detected: 85%
  [2026-01-23 10:17:12] ERROR: Failed to connect to API endpoint
  [2026-01-23 10:17:15] INFO: Retrying connection...
  [2026-01-23 10:17:18] ERROR: Connection timeout after 3 attempts
  [2026-01-23 10:18:00] INFO: Fallback mode activated

1. Extracting Timestamps:
  2026-01-23 10:15:30
  2026-01-23 10:15:31
  2026-01-23 10:15:32
  2026-01-23 10:16:45
  2026-01-23 10:17:12
  2026-01-23 10:17:15
  2026-01-23 10:17:18
  2026-01-23 10:18:00

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Find timestamps in sample log lines with a regular expression.

Kujo: Programming language for AI-native software
