# Capture function arguments

Make a reusable adder by capturing a value in a closure.

```kujo
func make_adder(x) {
    return func(y) {
        return x + y
    }
}

add5 := make_adder(5)
print(add5(3))  # Should print 8
print(add5(10)) # Should print 15

```

**Expected output:**

```text
8
15

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Make a reusable adder by capturing a value in a closure.

Kujo: Programming language for AI-native software
