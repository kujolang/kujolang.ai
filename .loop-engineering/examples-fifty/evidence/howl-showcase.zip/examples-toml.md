# Read and write TOML

Read server settings from TOML and write them back.

```kujo
# TOML parsing and generation

let toml_text := "title = \"Kujo\"\nversion = \"1.0.0\"\n[server]\nhost = \"127.0.0.1\"\nport = 8080"
let config := parse_toml(toml_text)

assert_equal(config["title"], "Kujo")
assert_equal(config["server"]["port"], 8080)

let generated := to_toml(config)
let round_trip := parse_toml(generated)

assert_equal(round_trip["server"]["host"], "127.0.0.1")
print("parsed TOML:", config)

```

**Expected output:**

```text
parsed TOML: {"server": {"host": 127.0.0.1, "port": 8080}, "title": Kujo, "version": 1.0.0}

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Read server settings from TOML and write them back.

Kujo: Programming language for AI-native software
