# Return errors as values

Return Ok or Err from division and handle each result.

```kujo
# Example 1: Division with error handling
func divide(a, b) {
    if b == 0 {
        return Err("Cannot divide by zero")
    }
    return Ok(a / b)
}

print("Example 1: Safe Division")
let result1 := divide(10, 2)
match result1 {
    case Ok(value): {
        print("10 / 2 = " + to_string(value))
    }
    case Err(error): {
        print("Error: " + error)
    }
}

let result2 := divide(10, 0)
match result2 {
    case Ok(value): {
        print("10 / 0 = " + to_string(value))
    }
    case Err(error): {
        print("Error: " + error)
    }
}

```

**Expected output:**

```text
Example 1: Safe Division
10 / 2 = 5
Error: Cannot divide by zero

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Return Ok or Err from division and handle each result.

Kujo: Programming language for AI-native software
