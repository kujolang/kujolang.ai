# Read and write CSV

Parse rows, read named fields and check a CSV round trip.

```kujo
# CSV parsing and generation

let csv_text := "name,age,active\nAlice,28,true\nBob,35,false"
let rows := parse_csv(csv_text)

assert_equal(len(rows), 2)
assert_equal(rows[0]["name"], "Alice")
assert_equal(rows[1]["age"], 35)

let generated := to_csv(rows)
let round_trip := parse_csv(generated)

assert_equal(len(round_trip), 2)
assert_equal(round_trip[0]["name"], "Alice")
print("parsed rows:", rows)
print("generated CSV:\n" + generated)

```

**Expected output:**

```text
parsed rows: [{"active": true, "age": 28, "name": Alice}, {"active": false, "age": 35, "name": Bob}]
generated CSV:
active,age,name
true,28,Alice
false,35,Bob


```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Parse rows, read named fields and check a CSV round trip.

Kujo: Programming language for AI-native software
