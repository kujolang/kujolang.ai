# Decode URL components

Turn percent-encoded URL text back into readable characters.

```kujo
print(decode_uri_component("caf%C3%A9%20%26%20tea"))
print(decode_uri_component("%E6%9D%B1%E4%BA%AC%2F%E6%A4%9C%E7%B4%A2"))

```

**Expected output:**

```text
café & tea
東京/検索

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Turn percent-encoded URL text back into readable characters.

Kujo: Programming language for AI-native software
