# Break and continue

Stop a loop early and skip even numbers.

```kujo
print("=== Break in While Loop ===")
x := 0
while true {
    print(x)
    x := x + 1
    if x >= 5 {
        break
    }
}
print("Broke out of loop")

print("")
print("=== Continue in While Loop ===")
y := 0
while y < 10 {
    y := y + 1
    if y % 2 == 0 {
        continue
    }
    print(y)
}

```

**Expected output:**

```text
=== Break in While Loop ===
0
1
2
3
4
Broke out of loop

=== Continue in While Loop ===
1
3
5
7
9

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Stop a loop early and skip even numbers.

Kujo: Programming language for AI-native software
