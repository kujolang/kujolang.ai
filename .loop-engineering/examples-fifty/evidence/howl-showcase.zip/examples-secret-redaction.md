# Redact secret values

Check how secret values appear in printed text and JSON.

```kujo
# Secret values redact automatically at output boundaries.

api_key := secret("sk-local-demo")

print(api_key)
print(to_json({"api_key": api_key, "label": "demo"}))
print(type(api_key))
print(is_secret(api_key))
print(reveal(api_key) == "sk-local-demo")

```

**Expected output:**

```text
***
{"api_key":"***","label":"demo"}
secret
true
true

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. The credentials in this sample are dummy values.

---

Check how secret values appear in printed text and JSON.

Kujo: Programming language for AI-native software
