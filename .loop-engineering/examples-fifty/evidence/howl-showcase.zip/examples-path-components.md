# Build file paths

Join path segments and extract a directory and filename.

```kujo
func print_lines(lines) {
    for line in lines {
        print(line)
    }
}

func section(title) {
    print("")
    print(title)
}

func kv(label, value) {
    print("  " + label + ": " + to_string(value))
}

print_lines([
    "=== Path Utilities Demo ===",
    ""
])

// Build paths
section("1. Building Paths:")
home_dir := "/home/user"
docs_path := join_path(home_dir, "Documents", "projects", "kujo")
kv("Home directory", home_dir)
kv("Documents path", docs_path)

config_path := join_path(home_dir, ".config", "kujo", "settings.json")
kv("Config path", config_path)

// Extract path components
section("2. Extracting Path Components:")
full_path := "/home/user/projects/kujo/examples/demo.kujo"
kv("Full path", full_path)
kv("Directory", dirname(full_path))
kv("Filename", basename(full_path))

```

**Expected output:**

```text
=== Path Utilities Demo ===


1. Building Paths:
  Home directory: /home/user
  Documents path: /home/user/Documents/projects/kujo
  Config path: /home/user/.config/kujo/settings.json

2. Extracting Path Components:
  Full path: /home/user/projects/kujo/examples/demo.kujo
  Directory: /home/user/projects/kujo/examples
  Filename: demo.kujo

```

Source pinned to 2cfaf185ad03059c89ef4f72fb061074255d00fc. Verification: run. 

---

Join path segments and extract a directory and filename.

Kujo: Programming language for AI-native software
